Trial MacroRat v1.5

-This tool used for Speed Looting and Ratting in ZvZ
-It will automatically track and click the item upon opening the chest or dead bodies 


-setup
* windows system
* albion online 'Vulkan or DirectX 11 API
* albion windows -borderless 
* 1920x1080 or 1280x720 'screen resolution -!ultra wide screen not yet supported


-usage
* press hold esc to stop looting


-bugs
* party loot -dont try to open chest with this tool "ON" because its going to try and loot the party loots or others loot on chest -try press hold esc button to solve the problem
